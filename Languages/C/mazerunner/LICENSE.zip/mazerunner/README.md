When the archive file is unpacked, you should have the following directory/file tree:

projtest/
  src/
    dbg.h
    libex29.c
  tests/
    dbg.h
    libex29_tests.c
    minunit.h
    runtests.sh
  LICENSE
  Makefile
  README.md

You can build and run the demo with the command 'make all' from the projtest directory.
To make the demo a skeleton for future projects, copy the tree to a new project directory:
'cp -r projtest YOURPROJECTDIRECTORY'
Then run 'make clean' and also be sure to remove or rename (if you intend to use them as
skeleton code) the src/libex29.c and tests/libex29_tests.c files.