#ifndef _maze_h
#define _maze_h

#include <stdio.h>
#include <stdlib.h>

//---- Directional Constants ------------------------------------------------//
#define NORTH 0
#define EAST  1
#define SOUTH 2
#define WEST  3

//---- Boolean Constants ----------------------------------------------------//
#define true  1
#define false 0

//---- Global Variables -----------------------------------------------------//
int gwidth;
int gheight;
char *grid;

//---- Function Prototypes
void InitMaze();
void ResetMaze();
int  XYToIndex(int x, int y);
int  IsInBounds(int x, int y);
void Visit(int x, int y);
void PrintMaze();
void setX(int x);
void setY(int y);

#endif
